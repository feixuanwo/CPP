#include <iostream>
using namespace std;
#include <ctime>
void sort(int a[], int n);

int main()
{
	const int N=10240;//10K
	int a[N];
	for(int i=0; i<N; i++) a[i]=N-i;//反序放数据
	clock_t t1 = clock();//排序前取得时间
	sort(a, N);//排序
	clock_t t2 = clock();//排序后再取得时间
	for(int i=0; i<10; i++) cout << a[i] << ' ';
	cout << endl;
	cout << "time:" << (t2-t1)/(CLOCKS_PER_SEC/1000.0) << endl;//计算排序用的时间，单位用毫秒
}






