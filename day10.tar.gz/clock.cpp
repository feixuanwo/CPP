#include <iostream>
using namespace std;
#include <ctime>

int main()
{
	cout << CLOCKS_PER_SEC << endl;
}

