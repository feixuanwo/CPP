#include <algorithm>
using std::swap;
void sort(int a[], int n)
{
	if(n<=1) return;
	if(n==2) {if(a[0]>a[1])swap(a[0],a[1]);return;}
	swap(a[n/2],a[0]);//标杆与第一个交换
	int pivot = a[0];//标杆
	int* L=a+1;
	int* R=a+n-1;
	while(L<R){
		while(L<R&&*L<pivot) ++L;//从左向右找不小的
		while(a<R&&*R>=pivot) --R;//从右向左找小的
		if(L<R) swap(*L,*R);//未相遇就交换
	}
	swap(a[0],*R);//标杆跟从右向左找到的数据交换
	sort(a,R-a);//对左边这组数据排序
	sort(R+1,n-(R-a)-1);//对右边这组数据排序
}





