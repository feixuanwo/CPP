#include <iostream>
using namespace std;
#include <iomanip>

typedef int T;
class bst{
	struct Node{//节点结构
		T data;
		Node* L;
		Node* R;
		Node(const T& d):data(d),L(),R(){}//构造函数
	};
	Node *root;//指向根节点
	int cnt;//目前节点个数
	void clear(Node*& tree){
		if(tree==NULL) return;
		clear(tree->L);
		clear(tree->R);
		delete tree; tree=NULL;
	}
	void insert(Node*& tree, Node* p){
		if(tree==NULL) tree = p;
		else if(p->data<tree->data)insert(tree->L,p);
		else insert(tree->R,p);
	}
	void insert(Node*& tree, const T& d){
		Node* p = new Node(d);
		insert(tree, p);
		++cnt;
	}
	void mtravel(Node* tree){
		if(tree==NULL) return;
		mtravel(tree->L);
		cout << tree->data << ' ';
		mtravel(tree->R);
	}
	Node*& find(Node*& tree, const T& d){
		if(tree==NULL) return tree;//没找到，返回空
		if(tree->data==d) return tree;//找到了，返回指针
		if(d<tree->data) return find(tree->L,d);
		else return find(tree->R,d);
	}
public:
	bst():root(),cnt(){}
	~bst(){clear(root);}
	void insert(const T& d){insert(root,d);}
	void mtravel(){mtravel(root);cout<<endl;}
	void clear(){clear(root);cnt=0;}
	bool remove(const T& d){
		Node*& r = find(root,d);
		if(r==NULL) return false;
		Node* p = r;
		if(p->L!=NULL) insert(p->R,p->L);
		r = p->R;
		delete p;
		--cnt;
		return true;
	}
	bool find(const T& d){
		return find(root,d)!=NULL;
	}
	bool update(const T& oldd, const T& newd){
		if(!remove(oldd)) return false;
		insert(newd);
		return true;
	}
	int size(){return cnt;}
	bool empty(){return cnt==0;}
	void print(int n, char c, Node* tree){
		if(tree==NULL) return;
		print(n+4,'/',tree->R);
		cout << setw(n+1) << c << tree->data << endl;
		print(n+4,'\\',tree->L);
	}
	void print(){print(0,'*',root);}
};

int main()
{
	bst b;
	b.insert(10);b.insert(3);b.insert(5);b.insert(2);b.insert(20);b.insert(15);b.insert(13);b.insert(18);
	b.mtravel();
	b.print();
	b.update(18,23);
	b.mtravel();
	b.print();
	b.update(10,21);
	b.mtravel();
	b.print();
}





