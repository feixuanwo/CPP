/*	反复N-1次
			从第i个到最后一个中找谁最小
				先假设第i个最小
				反复从第i+1个到最后一个
					如果谁更小，就假设这个最小
			把它跟第i个交换
*/
void sort(int a[], int n)
{
	for(int i=1; i<n; i++){//重复n-1次
		int min = i-1;//假设第i个最小
		int mv = a[min];//记录最小值
		for(int j=i; j<n; j++)//向后依次察看
			if(a[j]<mv) min=j,mv=a[min];//更新最小元素
		a[min]=a[i-1],a[i-1]=mv;//把最小元素跟第i个交换
	}
}



