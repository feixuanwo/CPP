#include <iostream>
using namespace std;
/*	在n个已序（sorted）数据数据中搜索值为d的数据
		如果n为0，查找失败结束
		如果中间位置那个数等于d，查找成功返回这个位置
		否则如果d小雨中间位置那个数，看在左边查找的结果
		否则看在右边查找的结果
*/
int* find(int a[], int n, int d){
	if(n==0) return NULL;
	int* mid = a+n/2;
	if(*mid==d) return mid;
	if(d<*mid) return find(a, n/2, d);
	else return find(mid+1,n-n/2-1,d);
}
int main()
{
	int a[12]={2,5,6,8,9,13,18,20,21,25,29,30};
	int* p1 = find(a,12,8);
	int* p2 = find(a,12,15);
	if(p1) cout << "at " << p1-a << endl;
	if(p2==NULL) cout<<"没找到15"<<endl;
}




