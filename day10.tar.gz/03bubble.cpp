inline void swap(int&x, int& y){int t=x;x=y;y=t;}
void sort(int a[], int n)
{
	bool swapped;
	do{
		swapped = false;
//		依次比较所有相邻的数据（对），如果两者的大小顺序不合要求就交换一下它们。这样称为一趟，最大的数到了最右边。
		for(int i=1; i<n; i++){
			if(a[i-1]>a[i]){
				swap(a[i-1],a[i]);
				swapped = true;
			}
		}
	}while(swapped);
//		重复这个过程直到这一趟没有发生交换为止。
}

