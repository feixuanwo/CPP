#include <iostream>
using namespace std;
#include <string>

template < typename T >
void sort(T a[], int n)
{
	for(int i=0; i<n; i++)
		for(int j=0; j<i; j++)
			if(a[i]<a[j])
				swap(a[i],a[j]);
}
int main()
{
	int ai[6]={8,1,6,9,3,5};
	char ac[5]={'d','x','s','a','m'};
	double ad[5]={5.5,3.3,9.9,6.6,2.2};
	string as[4]={"good","morning","dear","friends"};
	sort(ai, 6);
	sort(ac, 5);
	sort(ad, 5);
	sort(as, 4);
}



