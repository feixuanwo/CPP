//#include <iostream>
//using namespace std;

enum Color{
	RED,GREEN,BLUE
};
int main()
{
	enum Color c;
	c = 1;//GREEN
	void* p = &c;
	enum Color* q;
	q = p;
	return 0;
}

