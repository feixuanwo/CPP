#include <iostream>
using namespace std;

void show(const char* name, char gender='M');

int main()
{
	show("李舵");
	show("董达");
	show("王彤", 'F');
	show("戚小宝");
	show("凤姐", 'N');
}

void show(const char* name, char gender/*='M'*/)
{
	cout << name << "是个" << (gender=='M'?"帅哥":gender=='F'?"美女":"外星人") << endl;
}

