//#include <iostream>
//using namespace std;

enum Color{
	RED,GREEN,BLUE
};
int main()
{
	Color c;
	c = Color(1);
	void* p = &c;
	Color* q;
	q = (Color*)p;
	return 0;
}

