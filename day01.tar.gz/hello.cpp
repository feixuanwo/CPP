#include <iostream>//io头文件
using namespace std;
int main()
{
//	std::cout << "hello csd1212\n";//std是名字空间
	cout << "hello csd" << 1212 << ", welcome to C++" << '!' << endl;
	cout << "请输入姓名:";
	char name[20];
	cin >> name;
	cout << "达内欢迎你，" << name << "!\n";
	return 0;
}

