#include <iostream>
using namespace std;
inline int max(int a, int b)
{
	return a<b?b:a;
}
int main()
{
	int x = 10;
	int y = 20;
	int z =  max(x,y);//请求把max函数的代码嵌入到这里
	cout << z << endl;
}

