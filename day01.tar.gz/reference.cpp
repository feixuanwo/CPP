#include <iostream>
using namespace std;

void swap(int& p, int& q)
{
	cout << "&p=" << &p << ", &q=" << &q << endl;
	int t = p;
	p = q;
	q = t;
}
int& counter()
{
	static int cnt=0;//静态局部变量
	++cnt;
	return cnt;
}
int main()
{
	cout << counter() << endl;
	cout << counter() << endl;
	cout << counter() << endl;
	counter() = 0;
	cout << counter() << endl;
	cout << counter() << endl;
	int a=10, b=20,c=30,d=40; 
	cout << "&a=" << &a << ", &b=" << &b << endl;
	swap(a, b);
	cout << a << ',' << b << endl;
	swap(c, d);
	cout << "&c=" << &c << ", &d=" << &d << endl;
	cout << c << ',' << d << endl;
}

