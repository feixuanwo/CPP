#include <iostream>
using namespace std;

void show(int n)
{
	cout << "整数" << n << endl;
}
void show(double d)
{
	cout << "小数" << d << endl;
}
void show(int n, int m)
{
	cout << "一对整数" << n << ',' << m << endl;
}
struct Person{
	char name[20];
	char gender;
};
void show(Person p)
{
	cout << "一个" << (p.gender=='M'?"男":p.gender=='F'?"美":"外星") << "人,姓名" << p.name << endl;
}
int main()
{
	show(123);
	Person fj={"凤姐",'N'};
	show(fj);
	show(45.6);
	show(78,90);
	show(0.1F);
}

