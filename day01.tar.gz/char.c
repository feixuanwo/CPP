#include <stdio.h>
int main()
{
	printf("%d\n", sizeof('x'));
	return 0;
}

