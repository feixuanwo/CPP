#include <iostream>
using namespace std;
#include <cstring>
#include <new>
int main()
{
	int* pi = new int;
	int n = 200;
	char* pc = new char[n];
	double* pd = new(nothrow) double[~0];//失败
	long *pl = new long(123);//123
	short *ps = new short();//?
	*pi = 12*101;
	strcpy(pc, "达内欢迎你");
	if(pd!=NULL)
		pd[10] = 123.45;
	cout << *pi << ',' << pc << ',';
	if(pd) cout << pd[10] << ',';
	cout << *pl << ',' << *ps <<  endl;
	delete pi;
	delete[] pc;
	delete[] pd;
	delete pl;
	delete ps;
}

