#include <iostream>
#include <cstring>
using namespace std;
namespace czq{
	struct Student{
		char name[20];
		int age;
		void show(){
			cout << age << "岁的" << name << "轻松搞定C++" << endl;
		}
	};
}
int main()
{
	czq::Student s1={"芙蓉",18};
	using namespace czq;
	Student s2;
	strcpy(s2.name, "权哥");
	s2.age = 20;
	s1.show();
	s2.show();
	union {
		int x;
		char y[4];
	};//匿名联合
	x = 0x61626364;
	cout << y[0] << endl;
	y[1] = '0';//0x30
	cout << hex << showbase << x << endl;

	return 0;
}


