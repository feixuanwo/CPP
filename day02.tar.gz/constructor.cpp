//constructor.cpp
#include <iostream>
using namespace std;

class Cat{
	string name;
public:
	Cat(){cout << "call Cat()" << endl;}
	Cat(const char* n)
		{name=n;cout<<n<<"猫横空出世"<<endl;}
	void show(){cout<<"我是"<<name<<endl;}
};
class Dog{
	string name;
public:
	Dog(){cout << "call Dog()" << endl;}
	Dog(string n){cout<<n<<"犬降临人间"<<endl;}
};
int main()
{
	cout << "-------------" << endl;
	Cat c;//自动调用无参构造函数
	cout << "=============" << endl;
	Dog d;
	cout << "............" << endl;
	Cat c2("加菲");//自动调用带string参数的构造函数
	Dog d2("贵妃");
	cout << "************" << endl;
	Cat c3();//声明一个函数c3，返回类型Cat，参数表空。
	c = c2;
	c.show();
//	c = "波斯";//Cat ("波斯");匿名对象、类型转换
}



