/*写一个Person类,数据成员有姓名、出生年份，函数成员有birth(名字，年份)、show()显示姓名和年龄。*/
#include <iostream>
using namespace std;
#include <string>

class Person{
private://此行多余，默认就是私有
	string name;
	int year;
public:
	void birth(string n, int y);
	void show();
};
void Person::birth(string n, int y)
{
	name = n;
	year = y;
}
void Person::show()
{
	cout << "我是" << name << ", 今年" << 2013-year << endl;
}
/*在main里建两个不同年份的对象，设置好他们的姓名和年份之后让他们各自show一下自己。*/
int main()
{
	Person a, b;
	a.birth("芙蓉", 1991);
	b.birth("李召", 1990);
	a.show();
	b.show();
}

