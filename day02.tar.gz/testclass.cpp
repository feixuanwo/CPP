#include "myclass.h"

int main()
{
	sDate s;
	cDate c1, c2;
	s.set(2012,12,21);
	c1.set(1970,1,1);
	c2.set(2013,1,17);
	c1.print();
	c2.print();
	s.print();
}

