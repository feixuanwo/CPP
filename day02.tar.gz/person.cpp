#include <iostream>
using namespace std;
#include <string>
#include <cstdlib>
int thisyear;
class Person{
	string name;
	int year;
	bool gender;
	Person* lover;
public:
	Person(const string& name, bool gender){
		Person::name = name;
		year = thisyear;
		this->gender = gender;
		lover = NULL;
	}
	void show(){
		cout << "我是" << (gender?"帅哥":"美女") << name << ", 今年" << thisyear-year;
		if(lover)
			cout << ",跟" << lover->name << "恋爱中" << endl;
		else
			cout << ",单身" << endl;
	}
	Person(){
		name = "无名";
		//...
		cout << "一位无名大侠出世了" << endl;
		cout << "这是非法的，程序终止！" << endl;
		_Exit(0);
	}
	void love(Person& x){
		//Person* const this接受隐含参数，指向当前对象
		lover = &x;
		x.lover = this;
	}
	void fenshou(){
		lover = lover->lover = NULL;
	}
};

int main()
{
	thisyear = 1990;
	Person a("李召", true);
	thisyear = 1992;
	Person b("芙蓉", false);
	thisyear = 2013;
	a.show();//传递隐含参数a.show(&a);
	b.show();//传递隐含参数b.show(&b);
	b.love(a);
	a.show();
	b.show();
	b.fenshou();
	a.show();
	b.show();
//	Person c;//错：自动调用无参构造函数，但实际没有
//	cout << "娃哈哈，你看不到我滴" << endl;
}





