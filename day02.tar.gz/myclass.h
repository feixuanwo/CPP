#ifndef _MY_CLASS_H_
#define _MY_CLASS_H_
struct sDate{//全部成员都默认公开
	int year;
	int month;
	int day;
	void set(int y, int m, int d);
	void print();
};
class cDate{//默认不公开，private
	int year;
	int month;
	int day;
public://以下部分公开
	void set(int y, int m, int d);
	void print();
};
#endif

