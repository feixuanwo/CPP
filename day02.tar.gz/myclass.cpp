#include <iostream>
using namespace std;
#include "myclass.h"//必须包含头文件

void sDate::set(int y, int m, int d)//函数名前加限定
{
	year = y, month = m, day = d;
}
void sDate::print()
{
	cout << year << '-' << month << '-' << day << endl;
}
void cDate::set(int y, int m, int d)
{
	year = y, month = m, day = d;
}
void cDate::print()
{
	cout << year << '-' << month << '-' << day << endl;
}

