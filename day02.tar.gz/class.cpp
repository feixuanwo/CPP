#include <iostream>
using namespace std;

struct sDate{//全部成员都默认公开
	int year;
	int month;
	int day;
	void set(int y, int m, int d){
		year = y, month = m, day = d;
	}
	void print(){
		cout << year << '-' << month << '-' << day << endl;
	}
};
class cDate{//默认不公开，private
	int year;
	int month;
	int day;
public://以下部分公开
	void set(int y, int m, int d){
		year = y, month = m, day = d;
	}
	void print(){
		cout << year << '-' << month << '-' << day << endl;
	}
};
//MFC
int main()
{//extern
	sDate s;//定义（创建）对象s
	cDate c;//定义（创建）对象c
	s.set(2012,12,21);//使用对象
	c.set(2013,1,17);//使用对象
	s.print();//使用对象
	c.print();//使用对象
}

