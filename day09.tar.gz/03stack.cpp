#include <iostream>
using namespace std;
#include "list.h"

class Stack{//用组合不用继承，因为不是is-a
	List l;
public:
	void push(const T& d){l.push_front(d);}
	void pop(){l.pop_front();}
	T& top(){return l.front();}
	int size(){return l.size();}
	bool empty(){return l.size()==0;}
	bool full(){return false;}
};
int main()
{
	Stack s;
	s.push(1);s.push(2);s.push(3);s.push(4);
	while(!s.empty()){//直到取空为止
		cout << s.top() << endl;//取得栈顶元素
		s.pop();//删除栈顶元素
	}
}





