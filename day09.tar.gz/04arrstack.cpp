#include <iostream>
using namespace std;

class Stack{
	int data[5];
	int cnt;
public:
	Stack():cnt(0){}
	void push(const int d){
		if(full()) throw "栈满";
		data[cnt++]=d;//适合用后++
	}
	void pop(){
		if(empty()) throw "空栈";
		--cnt;
	}
	int& top(){
		if(empty()) throw "空栈";
		return data[cnt-1];
	}
	int size(){return cnt;}
	bool empty(){return cnt==0;}
	bool full(){return cnt==max_size();}
	int max_size(){return sizeof(data)/sizeof(*data);}
};

int main()
{
	Stack s;
	s.push(1);s.push(2);s.push(3);s.push(4);s.push(5);
	cout << "full?" << boolalpha << s.full() << endl;
	cout << s.top() << endl; s.pop();//取走栈顶元素
try{
	s.push(6);//成功
	s.push(7);//栈满异常
}catch(const char* e){
	cout << e << endl;
}
	while(!s.empty()){
		cout << s.top() << endl;
		s.pop();
	}
}





