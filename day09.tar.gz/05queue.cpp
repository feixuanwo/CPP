#include <iostream>
using namespace std;
typedef int T;
class Queue{
	T a[10];//数组
	int cnt;//当前元素个数
public:
	Queue():cnt(){}
	void push(const T& d){
		if(full()) throw "队列满";
		a[cnt++]=d;//新入的排在队尾
	}//  o o o o o o o o o o
	void pop(){
		for(int i=1; i<cnt; i++)//依次前移
			a[i-1] = a[i];
		--cnt;
	}
	T& front(){return a[0];}//队首
	T& back(){return a[cnt-1];}//队尾
	int size()const{return cnt;}
	int max_size()const{return sizeof(a)/sizeof(*a);}
	bool empty(){return cnt==0;}
	bool full(){return cnt==max_size();}
};
int main()
{
	int n;
	Queue q;
	cout << "请输入不超过10个整数:" << endl;
	while(cin >> n){//直到输入读取失败为止，Ctrl+D
		q.push(n);//cout << n << endl;
	}
	while(!q.empty()){
		cout << q.front() << ' ';
		q.pop();
	}
	cout << endl;
}




