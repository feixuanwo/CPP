#include <iostream>
using namespace std;
typedef int T;
class bst{
	struct Node{
		T data;
		Node* L;//指向左子树的根节点
		Node* R;//指向右子树的根节点
		Node(const T& d):data(d),L(),R(){}
	};
	Node* root;
	int cnt;
public:
	bst():cnt(),root(){}
	void clear(Node*& tree);
	void travel(Node* tree);
	void insert(Node*& tree, Node* p);
	Node*& find(Node*& tree, const T& d);
	void erase(Node*& p);
	void remove(Node*& tree, const T& d);
	void update(const T& oldd, const T& newd);
	int size();
	bool empty();
	//...
};
int main()
{
}

