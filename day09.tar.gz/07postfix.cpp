#include <iostream>
using namespace std;
#include <string>
#include <stack>
bool prior(char op1,char op2){
//	if(op2=='*'||op2=='/') return false;
//	if(op1=='+'||op1=='-') return false;
//	return true;
	return (op1=='*'||op1=='/')&&(op2=='+'||op2=='-');
}
int main()
{
	string res="";
	char c;
	stack<char> tmp;
	const char* str = "1+2*3/(4-5)+6";
//		反复读取输入内容直到结束为止
	while((c=*str++)!='\0'){
//			如果是数字直接入栈（或者入队）
		if(c>='0'&&c<='9')
			res += c;
//			否则如果是'('就等待处理括号里面的
		else if(c=='(')
			tmp.push(c);
//			否则如果是')’就倒回来处理直到左括号为止的全部运算
		else if(c==')'){
			while(tmp.top()!='('){
				res += tmp.top();//取得栈顶运算符
				tmp.pop();//去掉栈顶运算符
			}
			tmp.pop();//去掉左括号
		}
//			否则就是普通运算符
		else{
//				反复看那些暂存的未处理的运算符只要优先级不比本运算符低就处理（入栈或者入队）
			while(!tmp.empty()&&tmp.top()!='('&&!prior(c,tmp.top())){
				res += tmp.top();
				tmp.pop();
			}
//				暂存本运算符
			tmp.push(c);
		}
	}
//		反复所有暂存的运算符
	while(!tmp.empty()){
		res += tmp.top();
		tmp.pop();
	}
	cout << res << endl;
}

