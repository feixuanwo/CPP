#include <iostream>
using namespace std;
#include "list.h"
class Queue: private List{//用非公开继承或者组合
public:
	void push(const T& d){push_back(d);}//入队尾
	void pop(){pop_front();}//从队首出
	T& front(){return List::front();}
	T& back(){return List::back();}
	int size()const{return List::size();}
	int max_size(){return ~0u/sizeof(T);}
	bool empty(){return size()==0;}
	bool full(){return false;}
};
int main()
{
	Queue q;
	q.push(11);q.push(22);q.push(33);q.push(44);q.push(55);q.push(66);
	while(!q.empty()){
		cout << q.front() << ' ';
		q.pop();
	}
	cout << endl;
}





