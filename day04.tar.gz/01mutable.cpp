#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;
class A{//数组类，封装和增强数组的功能
	int* a;
	int len;
public:
	A(int n, int init=0):a(new int[n]),len(n),cur(0){
		for(int i=0; i<n; i++) a[i]=init;
	}
	~A(){
		delete[] a;a=NULL;
	}
	void set(int idx, int val){
		a[idx] = val;
	}
	int get(int idx)const{
		return a[idx];
	}
	void randfill(){
		srand(time(NULL));
		for(int i=0; i<len; i++)
			a[i] = rand()%100;
	}
	int size()const{//const表示不会修改成员变量值
		return len;
	}
	int next()const{
		return a[cur++%len];
	}
	mutable int cur;//const对象内部允许修改的成员
};
void use(const A& x)
{
	cout << x.size() << ":";
	for(int i=0; i<3; i++)cout << x.next() << ' ';
	cout << endl;
	for(int i=0; i<5; i++)cout << x.next() << ' ';
	cout << endl;
	for(int i=0; i<4; i++)cout << x.next() << ' ';
	cout << endl;
}
int main()
{
	A x(10);
	x.randfill();
	for(int i=0; i<x.size(); i++)
		cout << x.get(i) << ' ';
	cout << endl;
	use(x);
}




