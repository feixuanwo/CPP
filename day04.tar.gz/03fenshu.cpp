#include <iostream>
using namespace std;

class R{
	int n;//分子
	int d;//分母
public:
	//友元声明，向这个函数授权允许其访问本类成员
	friend ostream&operator<<(ostream&o,const R&x);
	R(int cn, int cd=1):n(cn),d(cd){
		//if(d==0)....
		if(d<0) n=-n, d=-d;
		for(int i=d; i>1; i--){
			if(d%i==0&&n%i==0){
				d/=i, n/=i;
				break;
			}
		}
	}
	friend istream& operator>>(istream& i, R& x)//x不要加const，用来输入。在类里面定义还是友元。
	{
		char c;
		int n, d;
		i >> n >> c >> d;//用户输入3/5，其中“/”要丢弃
		x = R (n,d);//匿名对象
		return i;
	}
	friend R operator+(const R& lh, const R& rh);
};
ostream& operator<<(ostream& o,const R& x)
{
	o << x.n << '/' << x.d;
	//operator<<(o,x.n)==>operator<<(ostream&,int)
	return o;
}
R operator+(const R& lh, const R& rh)
{
	return R(lh.n*rh.d+lh.d*rh.n,lh.d*rh.d);//匿名对象
}
int main()
{
	R a(6,8), b(8, -12);
	cout << a <<','<< b << endl;//operator<<(cout,a)
	cin >> a >> b;//operator>>(cin,a)
	cout << a << ',' << b << endl;
	cout << a + b << endl;//operator+(a,b)
	operator<<(cout, operator+(a,b)) << endl;
}
// (1+2)+3   (cout<<a)<<b;




