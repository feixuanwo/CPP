#include <iostream>
using namespace std;

class NA{
	int n;
	double d;
public:
	NA(){}
	NA* operator&(){return NULL;}
};
int main()
{
	NA a, b;
	cout << &a << endl;
	cout << &b << endl;
}




