//[]()->=type这些运算符只能是成员函数
#include <iostream>
#include <cstring>
using namespace std;
class S{
	char* p;
	int len;
private:
	S(const S& x);//私有拷贝构造，禁止拷贝
public:
	S(const char* str=""){
		len = strlen(str);
		p = new char[len+1];
		strcpy(p, str);
	}
	~S(){delete[] p;p=NULL;}
	S& operator=(const S& x){//以当前对象作为赋值结果
		if(&x==this) return *this;//自己给自己赋值
		len = x.len;
		delete[] p;//释放旧的动态内存
		p = new char[len+1];//为p开辟新动态内存
		strcpy(p, x.p);//复制动态内存中的字符串过来
		return *this;//返回当前对象
	}
	friend ostream& operator<<(ostream&o,const S&x){
		return o << x.p;//return o;
	}
	char& operator[](int idx){
		return p[idx];//可以先做越界检查
	}
};//m=n=r=100;
int main()
{
	S a, b("furong");//是初始化，不是赋值
	S c;
	c = a = b;//c.operator=(a.operator=(b))
	cout << a << ',' << b << ',' << c << endl;
	b = b;//b.operator=(b)
	cout << a[5] << endl;//a.operator[](5)
	a[1] = 'o';
	cout << a << endl;
}

