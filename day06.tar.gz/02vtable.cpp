#include <iostream>
#include <string>
using namespace std;

class Animal{
	string name;
	char gender;
public:
	virtual void eat(){cout<<"动物吃食物"<<endl;}
	void sleep(){cout<<"动物休息了"<<endl;}
	virtual void shout(){cout<<"动物叫"<<endl;}
};
class Cat : public Animal{
public:
	void eat(){cout<<"猫吃猫粮"<<endl;}
	void shout(){cout<<"猫喵喵叫"<<endl;}
};
class Dog : public Animal{
public:
	void eat(){cout<<"狗啃骨头"<<endl;}
	void sleep(){cout<<"狗狗睡觉了"<<endl;}
	void shout(){cout<<"狗旺旺叫"<<endl;}
};
class Jiafei : public Cat{
public:
	void eat(){cout<<"加菲吃意大利面"<<endl;}
	void shout(){cout<<"加菲说话"<<endl;}
};
class Person{
public:
	void play(Animal& a){a.sleep();a.eat();a.shout();}
};
int main()
{
	Dog d;
	Jiafei j;
	Person p;
	p.play(d);
	p.play(j);
	cout << sizeof(Animal) << endl;
}



