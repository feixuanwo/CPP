#include <iostream>
using namespace std;
class Vehicle{
public:
	virtual void stop(){cout<<"交通工具停止"<<endl;}
};
class Car : public Vehicle{
public:
	void stop(){cout<<"汽车踩离合踩刹车停住"<<endl;}
};
class Bike : public Vehicle{
public:
	void stop(){cout<<"自行车捏闸停住"<<endl;}
};
class Light{//交通信号灯
public:
	void stopvehicle(Vehicle& v){v.stop();}
};
int main()
{
	Light light;
	Car bmw;
	Bike yj;
	light.stopvehicle(bmw);
	light.stopvehicle(yj);
}





