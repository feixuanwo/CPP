#include <iostream>
using namespace std;
#include <string>

class Graph{//抽象类
	int x;
	int y;
public:
	Graph(int x, int y):x(x),y(y){}
	virtual double area()=0;//纯虚函数
	void show(){
		cout << Type() << "位置(" << x << ',' << y << "), 面积" << area() << endl;
	}
	virtual string Type()=0; //纯虚函数
};
class Rect : public Graph{
	int w;
	int h;
public:
	Rect(int x, int y, int w, int h):Graph(x,y),w(w),h(h){}
	double area(){return w*h;}
	string Type(){return "矩形";}
};
class Circle : public Graph{
	int r;
public:
	Circle(int x, int y, int r):Graph(x,y),r(r){}
	double area(){return 3.14*r*r;}
	string Type(){return "圆形";}
};
class Computer{
public:
	static void usegraph(Graph& g){g.show();}
};
int main()
{
	Circle c(8,8,10);
	Rect r(0,0,20,5);
	Computer::usegraph(c);
	Computer::usegraph(r);
	//Graph g(15,15);不能直接创建抽象类对象
}





