#include <iostream>
using namespace std;
class A{
public:
	A(){cout<<"A()"<<endl;}
	virtual ~A(){cout<<"~A()"<<endl;}
	virtual void dosomething(){}//=0;
};
class B : public A{
public:
	B(){cout<<"B()"<<endl;}
	~B(){cout<<"~B()"<<endl;}
	virtual void dosomething(){}
};
int main()
{
	A* x[2];
	x[0] = new B();
	x[1] = new A();
	//...做事情
	delete x[0];//A*, ~A()
	delete x[1];
}



