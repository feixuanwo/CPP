/*写一个Coder类，有两个纯虚函数code和decode。写一个rm类和一个divx类，分别继承Coder类并且实现那两个纯虚函数。写一个File类，有一个setcoder函数、zip函数和unzip函数。在main函数中使用这写类的对象。*/
#include <iostream>
using namespace std;
class Coder{
public:
	virtual void code(char* input, char* output)=0;
	virtual void decode(char* input, char* output)=0;
};
class rm : public Coder{
public:
	void code(char* input, char* output){
		cout << "用rm格式编码压缩" << endl;
	}
	void decode(char* input, char* output){
		cout << "用rm格式解压缩" << endl;
	}
};
class divx : public Coder{
public:
	void code(char* input, char* output){
		cout << "用divx格式编码压缩" << endl;
	}
	void decode(char* input, char* output){
		cout << "用divx格式解压缩" << endl;
	}
};
class File{
	Coder* p;
public:
	void setcoder(Coder& c){p=&c;}
	void zip(){
		char* source=NULL, *result=NULL;
		p->code(source, result);
		cout << "保存到文件中" << endl;
	}
	void unzip(){
		char* source=NULL, *result=NULL;
		p->decode(source, result);
		cout << "播放大片" << endl;
	}
};
int main()
{
	rm r;
	divx d;
	File f;
	f.setcoder(d);
	f.zip();
	f.unzip();
	f.setcoder(r);
	f.zip();
	f.unzip();
}

