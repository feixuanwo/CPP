#include <iostream>
using namespace std;

class Person{
public:
	virtual void show(){}
};
class Teacher : public Person{};
class Student : public Person{};
class CppTeacher : public Teacher{};
class Computer{
public:
	void start(){}
};
class Notebook : public Computer{};
class Company{
public:
	void test(Person* p){
		cout << "-------------------" << endl;
		Student* p1 = dynamic_cast<Student*>(p);
		if(p1){cout<<"是学生"<<endl;}
		Teacher* p2 = dynamic_cast<Teacher*>(p);
		if(p2){cout<<"是老师"<<endl;}
		CppTeacher* p3 = dynamic_cast<CppTeacher*>(p);
		if(p3){cout<<"是C++老师"<<endl;}
	}
};
int main()
{
	Computer* c = new Notebook();
	//dynamic_cast<Notebook*>(c);错，无虚函数
	Person* ps = new Student();
	Person* pt = new Teacher();
	Person* pc = new CppTeacher();
	Company tarena;
	tarena.test(pc);
	tarena.test(ps);
	tarena.test(pt);
	//delete ...
}



