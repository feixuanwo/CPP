/*写一个CSD1212Stu类，数据成员有姓名、性别（学号、成绩）、老师（教室），函数成员有报名、听课、换老师（教室）。*/
#include <iostream>
#include <string>
using namespace std;

class CSD1212Stu{
	static string teacher;
	string name;
	//bool gender;int num;float score;class dierti{}
public:
	CSD1212Stu(const string& n){name=n;}
	void listen(){cout<<name<<"在专注听"<<teacher<<"讲课"<<endl;}
	static void changeTeacher(const string &t){teacher=t;}
};
string CSD1212Stu::teacher = "杨老师";

/*在main函数里定义两个对象报名（姓名)、听课()、换老师(新老师)、听课()。*/
int main()
{
	CSD1212Stu a("安然");
	CSD1212Stu b("何冰");
	a.listen();
	b.listen();
	CSD1212Stu::changeTeacher("权哥");
	a.listen();
	b.listen();
}	

