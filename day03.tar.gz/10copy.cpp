#include <iostream>
using namespace std;
typedef int T;
class A{//数组类，封装和增强数组的功能
	T* a;
	int len;
public:
	A(int n, T init=T()):a(new T[n]){//零初始化
		for(int i=0; i<n; i++) a[i]=init;
		len = n;
		cout << a << "创建数组" << len << "个元素" << init << endl;
	}
	~A(){
		cout << "释放数组" << a << endl;
		delete[] a;a=NULL;
	}
	T& at(int idx){//返回引用
		if(idx<0||idx>=len)throw idx;//越界异常结束程序
		return a[idx];
	}
	int size(){return len;}
	void resize(int newsize, const T& val=T()){
		if(newsize<=len) len = newsize;//缩短在原地就够
		else{//加长得换地方
			T* np = new T[newsize];//申请新空间
			for(int i=0; i<len; i++) np[i]=a[i];//复制旧数据
			for(int j=len; j<newsize; j++) np[j]=val;//给新增元素赋值
			delete[] a;//释放旧空间
			a = np;//a指向新空间
			len = newsize;//记录新大小
		}
	}
	void print(){
		for(int i=0; i<len; i++) cout<<a[i]<<' ';
		cout << endl;
	}
	void fill(const T& start, const T& step=T()){//填充从start开始，步长为step（默认为0）
		for(int i=0; i<len; i++)
			a[i] = start+step*i;
	}
};
int main()
{
	A x(20);
	x.at(3)=5;
	cout<<x.size()<<":";x.print();
	A y(10,6);
	y.resize(15,9);
	cout<<y.size()<<":";y.print();
	x.fill(10,2);
	y.fill(20,-1);
	x.print();
	y.print();
}




