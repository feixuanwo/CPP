#include <iostream>
using namespace std;

class R{//分数类
	int n;//分子
	int d;//分母
public:
	R(int n, int d=1):n(n),d(d){//初始化列表
		cout << "R(" << n << '/' << d << ")" << endl;
	}
	R add(const R& r2){
		int nd = d * r2.d;
		int nn = d*r2.n+n*r2.d;
//		R result(nn, nd);
//		return result;
		return R (nn,nd);//匿名对象
	}
	void show(){
		cout << n << '/' << d << endl;
	}
	~R(){
		cout << "~(" << n << '/' << d << ")" << endl;
	}
};
int main()
{
	R a(2,5), b(3,4);
	a.add(b).show();
	cout << "---------------" << endl;
	a.add(R(3,8)).show();//匿名对象
	cout << "---------------" << endl;
	a.add(R(3)).show();//匿名对象
	cout << "---------------" << endl;
	a.add(3).show();//通过匿名对象自动类型转换R(3)
	cout << "===============" << endl;
}

