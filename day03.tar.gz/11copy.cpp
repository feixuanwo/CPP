#include <iostream>
using namespace std;
typedef int T;
class A{//数组类，封装和增强数组的功能
	T* a;
	int len;
public:
	A(int n, T init=T()):a(new T[n]){//零初始化
		for(int i=0; i<n; i++) a[i]=init;
		len = n;
		cout << a << "创建数组" << len << "个元素" << init << endl;
	}
	~A(){
		cout << "释放数组" << a << endl;
		delete[] a;a=NULL;
	}
	T& at(int idx){//返回引用,不复制
		if(idx<0||idx>=len)throw idx;//越界异常结束程序
		return a[idx];
	}
	int size(){return len;}
	void resize(int newsize, const T& val=T()){
		if(newsize<=len) len = newsize;//缩短在原地就够
		else{//加长得换地方
			T* np = new T[newsize];//申请新空间
			for(int i=0; i<len; i++) np[i]=a[i];//复制旧数据
			for(int j=len; j<newsize; j++) np[j]=val;//给新增元素赋值
			delete[] a;//释放旧空间
			a = np;//a指向新空间
			len = newsize;//记录新大小
		}
	}
	void print(){
		for(int i=0; i<len; i++) cout<<a[i]<<' ';
		cout << endl;
	}
	void fill(const T& start, const T& step=T()){//填充从start开始，步长为step（默认为0）
		for(int i=0; i<len; i++)
			a[i] = start+step*i;
	}
	A(const A& r){//r是x的引用（同一体）
	//拷贝构造函数：实参是个A类型的旧对象
		len=r.len;
		a = new T[len];//新对象的a指向一片新内存
		for(int i=0; i<len; i++)
			a[i] = r.a[i];
		cout << a<<"创建数组对象复制"<<r.a<<endl;
	}
};
//过滤数组中的偶数显示出来，返回原来的数组
A filter(A arr){//filter(x)新建对象arr用x初始化，调用拷贝构造函数A(const A& r),参数为x
	for(int i=0; i<arr.size(); i++)
		if(arr.at(i)%2==0) cout << arr.at(i) << ' ';
	cout << endl;
	return arr;//返回值对象用arr初始化
}
int main()
{
	A x(10);//创建数组对象
	x.fill(11,1);//填充11~20
	x.print();//显示11~20
	filter(x).print();//显示12 14...20,显示11~20
	//A arr(x),
	//A(A& rra){....}//A rra(x)
	//释放数组对象
}




