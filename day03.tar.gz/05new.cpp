#include <iostream>
using namespace std;
#include <string>

class File{
	string path;
public:
	File(const string& path="无名"):path(path)
	{/*:后的第一个path是成员，第二个是形参*/
		cout << "创建文件" << path << endl;
	}
};
int main()
{
//	File a;File b();空括号会导致被当成函数声明
	File* p1 = new File();//空括号可加可不加
	File* p2 = new File("/etc/passwd");
	File* p3 = new File[3];
	delete[] p3;p3=NULL;
	delete p1;p1=NULL;
	delete p2;p2=NULL;
}





