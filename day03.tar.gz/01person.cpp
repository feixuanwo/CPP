#include <iostream>
using namespace std;
#include <string>
#include <cstdlib>
int thisyear;
class Person{
	static int thisyear;//静态数据成员
	string name;
	int year;
	bool gender;
	Person* lover;
public:
	Person(const string& name, bool gender){
//		thisyear = ...;静态成员不应该在构造里初始化
		Person::name = name;
		year = thisyear;
		this->gender = gender;
		lover = NULL;
	}
	void show(){
		cout << "我是" << (gender?"帅哥":"美女") << name << ", 今年" << thisyear-year;
		if(lover)
			cout << ",跟" << lover->name << "恋爱中" << endl;
		else
			cout << ",单身" << endl;
	}
	Person(){
		name = "无名";
		//...
		cout << "一位无名大侠出世了" << endl;
		cout << "这是非法的，程序终止！" << endl;
		_Exit(0);
	}
	void love(Person& x){
		//Person* const this接受隐含参数，指向当前对象
		lover = &x;
		x.lover = this;
	}
	void fenshou(){
		lover = lover->lover = NULL;
	}
	static void timefly(int y){//人类时光飞逝
		thisyear = y;
	}
};
int Person::thisyear = 1990;//静态成员变量初始化

int main()
{
	Person::timefly(1990);
	Person a("李召", true);
	Person::timefly(1992);
	Person b("芙蓉", false);
	Person::timefly(2013);
	a.show();//传递隐含参数a.show(&a);
	b.show();//传递隐含参数b.show(&b);
	b.love(a);
	a.show();
	b.show();
	b.fenshou();
	a.show();
	b.show();
}





