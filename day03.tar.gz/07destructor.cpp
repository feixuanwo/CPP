#include <iostream>
using namespace std;
#include <string>
class Buffer{
	string name;
public:
	Buffer(const string& filename):name(filename){
		cout<<"为"<<filename<<"分配缓冲区"<<endl;
	}
	~Buffer(){
		cout<<"清理"<<name<<"的缓冲区"<<endl;
	}
};
class File{
	string path;
	Buffer* p;
public:
	File(const string& path="无名"):path(path),p(0)
	{/*:后的第一个path是成员，第二个是形参*/
		cout << this<<"创建文件" << path << endl;
	}
	~File(){//析构，对象释放时自动调用
		cout << this<<path << "释放" << endl;
		close();
	}
	void open(){
		p = new Buffer(path);//动态分配缓冲区资源
	}
	void close(){
		delete p;p=NULL;//释放缓冲区资源
	}
};
int main()
{
	File a("a");
	File* p2 = new File("/etc/passwd");
	a.open();
	p2->open();
	delete p2;p2=NULL;
}





