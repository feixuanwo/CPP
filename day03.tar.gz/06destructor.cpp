#include <iostream>
using namespace std;
#include <string>

class File{
	string path;
public:
	File(const string& path="无名"):path(path)
	{/*:后的第一个path是成员，第二个是形参*/
		cout << this<<"创建文件" << path << endl;
	}
	~File(){//析构，对象释放时自动调用
		cout << this<<path << "释放" << endl;
	}
};
int main()
{
	{
		File a("a");//File b();空括号会导致被当成函数声明
		cout << "---------------" << endl;
	}
	File* p1 = new File();//空括号可加可不加
	File* p2 = new File("/etc/passwd");
	File* p3 = new File[2];
	delete[] p3;p3=NULL;
	delete p1;p1=NULL;
	delete p2;p2=NULL;
}





