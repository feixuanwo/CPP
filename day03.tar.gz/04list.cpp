//单例模式
#include <iostream>
using namespace std;
class ChairMan{
	ChairMan(string name):name/*成员*/(name)
	{}
public:
	const string name;
	static ChairMan&/*引用*/ getInstance(){//静态成员
		static ChairMan cm("习近平");//静态局部变量
		return cm;
	}
	void show(){
		cout << "同志们好！我是主席" << name << endl;
	}
};
int main()
{
	//ChairMan c1("***");
	ChairMan& c = ChairMan::getInstance();
	c.show();
//	c.name = "芙蓉";
//	c.show();
	
}

