#include <iostream>
using namespace std;
#include <string>
class Person{
	string name;
public:
	const string& getName(){return name;}
	Person(const char* n):name(n){
		cout << "Person(" << n << ")" << endl;
	}
	~Person(){
		cout << "~Person()" << endl;
	}
	void show(){
		cout << "大家好，我是" << name << endl;
	}
};
class Teacher : public Person{
	string course;
public:
	Teacher(const char* n, const char* c)
		:course(c),Person(n){
			//Person(n);//只是创建匿名对象
			cout << "Teacher("<<n<<","<<c<<")\n";
	}
	~Teacher(){
		cout << "~Teacher()" << endl;
	}
	void show(const char*c){//隐藏来自父类的同名函数
		cout << c << "班的同学们好！我是" << course << "课程的老师" << getName() << ",希望咱们一起把它学好！\n";
	}
};
int main()
{
	Person b("芙蓉");
	Teacher a("杨健", "C语言");
	b.show();
	a.show("csd1212");//调用子类的show函数
	a.Person::show();//调用来自父类的show函数
}




