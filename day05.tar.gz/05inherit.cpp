#include <iostream>
using namespace std;
#include <string>

class Person{
protected://允许在子类中直接访问，别的地方不允许
	string name;
public:
	void setname(const char* n){
		name = n;
	}
	void eat(string food){
		cout << name << "吃" << food << endl;
	}
	void speak(string words){
		cout << name << "说:\"" << words << "\"\n";
	}
};
class Teacher : public Person{
	string course;
public:
	void teach(string someclass){
		cout << name << "给" << someclass << "班讲" << course << "课程" << endl;
	}
	void setcourse(string c){course = c;}
};
int main()
{
	Person a;
	Teacher c;
	a.setname("芙蓉");
	c.setname("权哥");
	a.eat("水煮鱼");
	c.eat("炸酱面");
	a.speak("我会跳舞");
	c.speak("大家好才是真的好");
	c.setcourse("C++");
	c.teach("csd1212");
}





