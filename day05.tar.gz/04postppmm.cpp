#include <iostream>
using namespace std;

class R{
	int n;
	int d;
public:R(int n=0, int d=1):n(n),d(d){}
	friend ostream& operator<<(ostream&, const R&);
	R operator++(int){//返回类型不应该加引用
	//虚假的形参int用于与前++区分，是哑元
		R old=*this;
		n += d;
		return old;
	}//cout << a << ++++a << a << endl;不要这样
};

int main()
{
	R a(3,5);
	cout << a++ << endl;//a.operator++(0)后++会传一个无用的参数0
	cout << a << endl;
}
ostream& operator<<(ostream& o, const R& x)
{
	return o << x.n << '/' << x.d;
}




