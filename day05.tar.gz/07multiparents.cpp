#include <iostream>
using namespace std;
#include <string>
class Phone{
public:
	Phone(){cout<<"Phone()"<<endl;}
	void call(string num){
		cout << "打电话给" << num << endl;
	}
};
class Camera{
public:
	Camera(){cout<<"Camera()"<<endl;}
	void takephoto(string target){
		cout << "照了一张" << target << "照\n";
	}
};
class CellPhone : public Phone, public Camera{
public:
	//按照继承顺序调用父类构造函数
	CellPhone():Camera(),Phone()//零初始化
	{cout<<"CellPhone()"<<endl;}
};
int main()
{
	CellPhone ok;
	ok.call("芙蓉");
	ok.takephoto("风景");
}





