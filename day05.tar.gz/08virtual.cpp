#include <iostream>
using namespace std;
#include <string>
class Person{
	string name;
public:
	Person(const char* n):name(n){
		cout << "Person("<<n<<")\n";
	}
	const string& Name()const{return name;}
};
class Teacher : virtual public Person{
	string course;
public:
	Teacher(const char* n, const char* c)
	:course(c), Person(n){
		cout << "Teacher("<<n<<","<<c<<")\n";
	}
	void teach(const char* c){
		cout<<Name()<<"老师在"<<c<<"班讲"<<course<<endl;
	}
};
class Student : virtual public Person{
	string sid;//学号
public:
	Student(const char* n, const char* s)
	:sid(s), Person(n){
		cout<<"Student("<<n<<","<<s<<")\n";
	}
	void listen(const char* room){
		cout<<Name()<<"在"<<room<<"听课"<<endl;
	}
};
class DoubleMan : public Student, public Teacher{
public:
	DoubleMan(const char*n, const char* c, const char* id):Teacher(n,c),Student(n,id),Person(n){
		cout<<"DoubleMan("<<n<<','<<c<<','<<id<<")\n";
	}
};	
int main()
{
	DoubleMan a("权哥","C++","BIT123");
	a.teach("csd1212");
	a.listen("318");
	cout << "hello, " << a.Name() << endl;
}




