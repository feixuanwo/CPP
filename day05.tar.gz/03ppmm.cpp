#include <iostream>
using namespace std;
class R{//分数类
	int n;
	int d;
public:
	friend ostream&operator<<(ostream&o,const R&x){
		return o << x.n << '/' << x.d; 
	}
	R(int n, int d):n(n),d(d){}
	R& operator++(){//成员形式的前++
		n += d;
		return *this;
	}
	//非成员形式（友元形式）的前--
	friend R& operator--(R& x){
		x.n -= x.d;
		return x;//不能是*this，因为不是成员函数无this
	}//--a: operator--(a)
};
int main()
{
	R a(3,4);
	cout << "a=" << a << endl;
	cout << "a=" << ++ ++a << endl;
	cout << "a=" << a << endl;
	//operator++(a), a.operator++()
	cout << ----a << endl;//operator--(a), a.operator--()
	cout << a << endl;
}




