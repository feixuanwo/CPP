#include <iostream>
using namespace std;
#include <string>
class Person{
	string name;
	bool gender;
public:
	Person(const char* n,bool g):name(n),gender(g){}
	virtual void show()const{
		cout << "大家好！我是超级" << (gender?"帅哥":"美女") << name << endl;
	}
	const string& Name()const{return name;}
};
class Teacher : public Person{
	string course;
public:
	Teacher(const char* n, const char* c, bool g)
	:Person(n,g),course(c){}
	void show()const{
		cout << "各位同学好！我是" << course << "老师" << Name() << ",请大家跟我上，搞定" << course << endl;
	}
};
int main()
{
	Person* p = new Teacher("杨健", "C语言", true);
	p->show();
	delete p;
}






