/*小练习：写一个程序，对一个指定文件进行加密/解密。加密把每个字节的数据都按位取反并且加上66保存回去，解密则是把每个字节减去66并且按位取反之后保存回去。要求程序运行时命令行格式：
		a.out -c|-d 文件名
如果用户使用的格式不对则提示出正确的用法。*/
#include <iostream>
using namespace std;
#include <fstream>
#include <cstring>

int main(int argc, char* argv[])
{
	if(argc!=3){
		cout << *argv << " -c|-d 文件名" << endl;
		return 0;
	}
	fstream f(argv[2],ios::in|ios::out);
	if(!f){
		cout << "打开文件失败" << endl;
		return 1;
	}
	char c;
	if(strcmp(argv[1],"-c")==0){//加密
		while(f.get(c)){
			f.seekp(-1,ios::cur);//退回原位置
			f.put(~c+66);//覆盖原来的字符
		}
	}
	else if(strcmp(argv[1],"-d")==0){//解密
		while(f.get(c)){
			f.seekp(-1,ios::cur);
			f.put(~(c-66));
		}
	}
	else{
		cout << "无效选项，只能是-c或者-d" << endl;
		return 0;
	}
	f.close();
}


