#include <iostream>
#include <map>
using namespace std;
#include <string>
//班委任命
int main()
{
	map<string,string> mss;
	mss.insert(pair<string,string>("班长","芙蓉"));
	mss.insert(make_pair("学委", "爱爱"));
	mss.insert(map<string,string>::value_type("生委", "凤姐"));
	mss.insert(make_pair("学委", "蒙哥"));//丢弃重复
	mss["班长"] = "菲菲";//已经存在的key，取得value&
	mss["团委"] = "小乔";//不存在的key，新建一个元素以此为key，取得value&
	map<string,string>::iterator it;
	for(it=mss.begin(); it!=mss.end(); it++)
		cout << it->first << ':' << it->second << endl;

}



