#include <iostream>
using namespace std;
#include <map>
int main()
{
	multimap<string, double> msd;
	msd.insert(make_pair("张赛",10000));
	msd.insert(make_pair("刘婧婧",50000));
	msd.insert(make_pair("刘婧婧",30000));
	msd.insert(make_pair("张赛",20000));
	msd.insert(make_pair("刘婧婧",80000));
	msd.insert(make_pair("张赛",70000));
	msd.insert(make_pair("刘婧婧",90000));
	msd.insert(make_pair("刘婧婧",50000));
	msd.insert(make_pair("张赛",80000));
	multimap<string,double>::iterator it=msd.begin();
	string name;
	double money;
	while(it!=msd.end()){
		name = it->first;
		money = it->second;
		while(++it!=msd.end()&&it->first==name)
			money += it->second;
		cout << name << ":" << money << endl;
	}
}

