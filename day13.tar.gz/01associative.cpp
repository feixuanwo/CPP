#include <iostream>
using namespace std;
#include <set>
#include "print.h"

struct func1{
	bool operator()(int x, int y)const{return x<y;}
};
struct func2{
	bool operator()(int x, int y)const{return x>y;}
};
int main()
{
	int a[8]={8,9,2,8,6,1,8,2};
	multiset<int, func1> s1(a,a+8);
	multiset<int, func2> s2;
	for(int i=0; i<8; i++) s2.insert(a[i]);
	print(s1.begin(), s1.end());
	print(s2.begin(), s2.end());
	multiset<int,func1>::iterator c,b,it=s1.find(6);
	if(it==s1.end())cout<<"没找到6"<<endl;
	else{
		c = b = it;
		cout<<"找到6在"<<*--c<<"和"<<*++b<<"之间\n";
	}
	b = s1.lower_bound(8), c = s1.upper_bound(8);
	pair<multiset<int,func1>::iterator,multiset<int,func1>::iterator> x=s1.equal_range(8);//8所在区间
	print(b,c);
	print(x.first,x.second);
	cout << "8的个数：" << s1.count(8) << endl;
	s1.erase(2);//删除所有key为2的元素
	print(s1.begin(), s1.end());
}






