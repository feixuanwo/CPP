#ifndef CZQ_PRINT
#define CZQ_PRINT

#include <iostream>
using namespace std;

template < typename It >
void print(It beg, It end)
{
	while(beg!=end)
		cout << *beg++ << ' ';
	cout << endl;
}

#endif

