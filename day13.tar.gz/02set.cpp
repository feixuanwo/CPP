//达人代表选举
#include <iostream>
#include <set>
using namespace std;
#include <string>
#include "print.h"

int main()
{
	set<string> ss;
	cout << "候选人提名:";
	
	string name;//尽量不要在循环里面定义对象
	for(;;){
		cin >> name;
		if(name==".") break;
		ss.insert(name);
	}
	cout << "候选人名单出炉：" << endl;
	print(ss.begin(), ss.end());
	cout << "开始选举，请投票:\n";
	set<string>::iterator it=ss.begin();
	int i=0;
	while(it!=ss.end()){
		cout << ++i << ':' << *it++ << endl;
	}
	multiset<int> mi;
	int id,cnt=ss.size();
	while(cin>>id){//出错或者Ctrl+D结束
		if(id<1||id>cnt){cout<<id<<"无效"<<endl;}
		else mi.insert(id);//记录有效投票
	}
	it = ss.begin();
	i = 0;
	int max=-1;
	name = "";
	while(it!=ss.end()){
		cnt = mi.count(++i);//统计投票数
		if(cnt!=0){
			if(cnt>max){max=cnt;name=*it; }//记录最高得票和姓名
			cout << *it << ':' << cnt << endl;
		}
		++it;//下一个名字
	}
	cout << name << "以" << max << "票当选" << endl;
}









