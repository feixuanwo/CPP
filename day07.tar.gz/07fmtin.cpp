#include <iostream>
using namespace std;
#include <cctype>
istream& func(istream& i)
{ //	cout << "排除非数字字符";
	char c;
	do i>>c; while(!isdigit(c));//取走非数字字符
	i.putback(c);//退回一个字符
	return i;//i就是cin
}
int main()
{
	int n=-1;
	cin >> func >> n;//func(cin);
	//cin >> n;
	//cin >> func;//cin.operator>>(func)==>func(cin)
	cout << "n = " << n << endl;
}

