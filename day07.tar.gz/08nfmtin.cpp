#include <iostream>
using namespace std;

int main()
{
	char a, b, c, d, e, f;
	cout << "请输入一些字符:" << endl;
	a = cin.get();//1
	cin.get(b);//2
	cin.ignore();//3x
	cin.get(c);//4
	d = cin.peek();//5.
	cin.get(e);//5
	cin.putback(e);//5<-
	cin.get(f);//5
	cout << a << b << c << d << e << f << endl;
}

