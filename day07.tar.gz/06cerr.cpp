#include <iostream>
using namespace std;
#include <unistd.h>//windows.h
int main()
{//fflush
	cerr << "world";//不缓冲，立即显示
	cout << "hello";//缓冲：满，结束，刷新，换行符，输入等条件下才显示到屏幕上
	sleep(10);//Sleep(10*1000)
//	cout << endl;
}

