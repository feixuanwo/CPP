#include <iostream>
using namespace std;
#include <string>
int main()
{
	char buf[10];
	cin.getline(buf,10);
	cout << buf;
	if(!cin){
		cin.clear();//清除错误状态
		string str;
		getline(cin, str);
		cout << "[E]" << str;
	}
	cout << endl;
}




