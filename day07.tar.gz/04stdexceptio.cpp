#include <iostream>
using namespace std;
#include <exception>

int main()
{
	try{
		double* p = new double[~0];//抛出异常
		cout << p << endl;//一定不会执行
	}
	catch(exception& e){
		cout << "发生异常" << e.what() << endl;
	}
	cout << "oh yeah" << endl;
}

