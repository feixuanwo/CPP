#include <iostream>
using namespace std;
void beforedie(){cout<<"共产党万岁"<<endl;}
void func()
{
	class MyExc{};
	cout << "请选择一种死法:" << endl;
	cout << "\t1--抛出整数" << endl;
	cout << "\t2--抛出小数" << endl;
	cout << "\t3--抛出C字符串" << endl;
	cout << "\t4--自尽" << endl;
	cout << "\t0--免死" << endl;
	int n;
	cin >> n;
	switch(n){
	case 1:	throw 123;
	case 2:	throw 4.5;
	case 3:	throw "hello";
	case 4: throw MyExc();
	case 0: break;
	default: throw 789L;
	}
}
int main()
{
	set_terminate(beforedie);
	func();
	cout << "-----美好的未来-----" << endl;
}



